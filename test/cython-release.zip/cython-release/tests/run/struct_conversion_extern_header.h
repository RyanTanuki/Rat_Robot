struct my_date_t {
    int year;
    int month;
    int day;
};
